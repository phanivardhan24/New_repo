import streamlit as st
import pickle
import pandas as pd

# Load the model
with open("best_model.pkl", "rb") as file:
    model = pickle.load(file)

st.title("Autism Prediction App")
st.write("Fill in the details to predict whether the individual might have autism.")

# Input form
with st.form("autism_form"):
    A1 = st.selectbox("A1 Score", [0, 1])
    A2 = st.selectbox("A2 Score", [0, 1])
    A3 = st.selectbox("A3 Score", [0, 1])
    A4 = st.selectbox("A4 Score", [0, 1])
    A5 = st.selectbox("A5 Score", [0, 1])
    A6 = st.selectbox("A6 Score", [0, 1])
    A7 = st.selectbox("A7 Score", [0, 1])
    A8 = st.selectbox("A8 Score", [0, 1])
    A9 = st.selectbox("A9 Score", [0, 1])
    A10 = st.selectbox("A10 Score", [0, 1])
    age = st.slider("Age", 1, 100, 22)
    gender = st.radio("Gender", ["Male", "Female"])
    ethnicity = st.number_input("Ethnicity (encoded)", value=3)
    jaundice = st.radio("Jaundice at birth", ["No", "Yes"])
    used_app_before = st.radio("Used screening app before", ["No", "Yes"])
    result = st.slider("AQ-10 Score (result)", 0, 10, 7)
    relation = st.number_input("Relation (encoded)", value=2)
    contry_of_res = st.number_input("Country of Residence (encoded)", value=4)
    
    submit = st.form_submit_button("Predict")

if submit:
    # Encode categorical variables
    gender_val = 1 if gender == "Male" else 0
    jaundice_val = 1 if jaundice == "Yes" else 0
    app_val = 1 if used_app_before == "Yes" else 0

    # Match input features
    input_data = pd.DataFrame([{
        'A1_Score': A1,
        'A2_Score': A2,
        'A3_Score': A3,
        'A4_Score': A4,
        'A5_Score': A5,
        'A6_Score': A6,
        'A7_Score': A7,
        'A8_Score': A8,
        'A9_Score': A9,
        'A10_Score': A10,
        'age': age,
        'gender': gender_val,
        'ethnicity': ethnicity,
        'jaundice': jaundice_val,
        'austim': 0,  # dummy feature (was wrongly included in training)
        'contry_of_res': contry_of_res,
        'used_app_before': app_val,
        'result': result,
        'relation': relation
    }])

    prediction = model.predict(input_data)[0]
    st.success("Prediction: **{}**".format("Autistic" if prediction == 1 else "Not Autistic"))
